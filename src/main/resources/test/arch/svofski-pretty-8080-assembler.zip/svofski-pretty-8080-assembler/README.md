# Pretty Intel 8080 Assembler

Works right in the browser. The code is being translated immediately as you type it and the result can be downloaded as a hex or bin file, or executed in CP/M environment within an online emulator (see [vector06js](https://github.com/svofski/vector06js) ). The live listing view provides extensive cross referencing and navigation features.

It is hosted at https://svofski.github.io/pretty-8080-assembler/ — go there and give it a try.

(c) 2009-2018 Viacheslav Slavinsky http://sensi.org/~svo
